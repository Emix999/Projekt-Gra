-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 03 Lis 2023, 08:07
-- Wersja serwera: 10.4.27-MariaDB
-- Wersja PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `domki3110`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `mieszkania`
--

CREATE TABLE `mieszkania` (
  `Nrdomku` tinyint(4) NOT NULL,
  `LiczbaPokoi` tinyint(3) UNSIGNED NOT NULL,
  `Garaz` enum('Tak','Nie') DEFAULT NULL,
  `CenaZaDobe` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `mieszkania`
--

INSERT INTO `mieszkania` (`Nrdomku`, `LiczbaPokoi`, `Garaz`, `CenaZaDobe`) VALUES
(1, 4, 'Tak', 200),
(2, 4, 'Nie', 160),
(3, 2, 'Tak', 120),
(4, 2, 'Nie', 100),
(5, 3, 'Tak', 170),
(6, 3, 'Nie', 140),
(7, 5, 'Tak', 250),
(8, 5, 'Nie', 200),
(9, 6, 'Tak', 300);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `NrRezerwacji` int(11) NOT NULL,
  `IdPracownika` int(11) DEFAULT NULL,
  `NrDomku` tinyint(4) DEFAULT NULL,
  `LiczbaDni` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `rezerwacje`
--

INSERT INTO `rezerwacje` (`NrRezerwacji`, `IdPracownika`, `NrDomku`, `LiczbaDni`) VALUES
(1, 5, 2, 2),
(2, 20, 5, 2),
(3, 35, 6, 3),
(4, 26, 2, 2),
(5, 58, 3, 4),
(6, 72, 6, 2),
(7, 74, 8, 4),
(8, 85, 7, 10),
(9, 57, 6, 4),
(10, 50, 9, 2),
(11, 36, 5, 4),
(12, 24, 4, 1),
(13, 78, 3, 7),
(14, 53, 4, 2),
(15, 6, 6, 2),
(16, 61, 5, 7),
(17, 31, 3, 6),
(18, 51, 2, 3),
(19, 37, 8, 5),
(20, 47, 1, 5),
(21, 19, 2, 2),
(22, 29, 4, 4),
(23, 84, 2, 10),
(24, 65, 5, 2),
(25, 49, 6, 1),
(26, 64, 3, 7),
(27, 97, 2, 8),
(28, 76, 7, 2),
(29, 55, 5, 3),
(30, 59, 3, 4),
(31, 79, 2, 7),
(32, 88, 7, 4),
(33, 48, 5, 1),
(34, 93, 9, 4),
(35, 17, 9, 5),
(36, 15, 9, 3),
(37, 86, 8, 10),
(38, 25, 5, 2),
(39, 44, 3, 2),
(40, 96, 2, 3),
(41, 56, 4, 2),
(42, 11, 6, 3),
(43, 40, 8, 2),
(44, 7, 4, 2),
(45, 32, 2, 3),
(46, 9, 1, 2),
(47, 38, 5, 4),
(48, 81, 7, 7),
(49, 62, 8, 7),
(50, 77, 4, 2),
(51, 70, 6, 4),
(52, 89, 9, 2),
(53, 12, 8, 4),
(54, 8, 7, 2),
(55, 95, 2, 2),
(56, 69, 2, 4),
(57, 75, 3, 2),
(58, 18, 7, 6),
(59, 60, 6, 2),
(60, 82, 4, 8),
(61, 34, 7, 3),
(62, 27, 5, 2),
(63, 30, 4, 5),
(64, 28, 7, 3),
(65, 16, 8, 4),
(66, 71, 6, 3),
(67, 10, 4, 2),
(68, 13, 2, 5),
(69, 45, 1, 3),
(70, 42, 1, 2),
(71, 83, 1, 8),
(72, 87, 1, 2),
(73, 41, 5, 3),
(74, 90, 7, 5),
(75, 46, 5, 4),
(76, 91, 3, 7),
(77, 94, 8, 3),
(78, 66, 6, 3),
(79, 80, 8, 7),
(80, 63, 9, 7),
(81, 92, 6, 5),
(82, 4, 6, 3),
(83, 22, 8, 2),
(84, 43, 3, 2),
(85, 52, 2, 2),
(86, 39, 3, 2),
(87, 67, 1, 4),
(88, 33, 1, 3),
(89, 54, 9, 2),
(90, 23, 7, 2),
(91, 1, 5, 5),
(92, 14, 4, 4),
(93, 2, 3, 5),
(94, 68, 4, 5),
(95, 3, 2, 5),
(96, 73, 3, 3),
(97, 21, 4, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uczen`
--

CREATE TABLE `uczen` (
  `Idpracownika` int(11) NOT NULL,
  `Nazwisko` varchar(50) DEFAULT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `wiek` tinyint(3) UNSIGNED DEFAULT NULL,
  `data urodzenia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `uczen`
--

INSERT INTO `uczen` (`Idpracownika`, `Nazwisko`, `imie`, `wiek`, `data urodzenia`) VALUES
(1, 'Wroblewski', 'Jan', NULL, NULL),
(2, 'Wiecek', 'Jaremi', NULL, NULL),
(3, 'Zawada', 'Witold', NULL, NULL),
(4, 'Ulatowski', 'Edwin', NULL, NULL),
(5, 'Adamski', 'Adam', NULL, NULL),
(6, 'Gosciniak', 'Agnieszka', NULL, NULL),
(7, 'September', 'Agnieszka', NULL, NULL),
(8, 'Owocka', 'Agnieszka', NULL, NULL),
(9, 'Mikolajczyk', 'Aldona', NULL, NULL),
(10, 'Rokicka', 'Aleksandra', NULL, NULL),
(11, 'lis', 'Andrzej', NULL, NULL),
(12, 'Opielski', 'Andrzej', NULL, NULL),
(13, 'Sadej', 'Andrzej', NULL, NULL),
(14, 'Zajdowicz', 'Arleta', NULL, NULL),
(15, 'Kuryllo', 'Artur', NULL, NULL),
(16, 'Ratajczyk', 'Artur', NULL, NULL),
(17, 'Kujawa', 'Bogdan', NULL, NULL),
(18, 'Prokopowicz', 'Bogdan', NULL, NULL),
(19, 'Hamerak', 'Blazej', NULL, NULL),
(20, 'Antasowski', 'Dariusz', NULL, NULL),
(21, 'Zielinska', 'Dariusz', NULL, NULL),
(22, 'Walkusz', 'Elzbieta', NULL, NULL),
(23, 'Wrobl', 'Elzbieta', NULL, NULL),
(24, 'Garbatowska', 'Ewa', NULL, NULL),
(25, 'lazowski', 'Ewa', NULL, NULL),
(26, 'Bardzewska', 'Grazyna', NULL, NULL),
(27, 'Radziemski', 'Grzegorz', NULL, NULL),
(28, 'Rak', 'Grzegorz', NULL, NULL),
(29, 'Iwanowska', 'Hanka', NULL, NULL),
(30, 'Rajkowski', 'Hieronim', NULL, NULL),
(31, 'Gorna', 'Ilona', NULL, NULL),
(32, 'Magdzinska', 'Irena', NULL, NULL),
(33, 'Wojtasiak', 'Jacek', NULL, NULL),
(34, 'Radke', 'Jan', NULL, NULL),
(35, 'Baran', 'Janusz', NULL, NULL),
(36, 'Fratczak', 'Janusz', NULL, NULL),
(37, 'Hadynski', 'Jaroslaw', NULL, NULL),
(38, 'Mikulajewski', 'Jerzy', NULL, NULL),
(39, 'Wilkowska', 'Kamila', NULL, NULL),
(40, 'lisiecki', 'Karol', NULL, NULL),
(41, 'Stachowiak', 'Katarzyna', NULL, NULL),
(42, 'Sikorska', 'Kinga', NULL, NULL),
(43, 'Wawrzyniak', 'Krzysztofa', NULL, NULL),
(44, 'laczkowski', 'leszek', NULL, NULL),
(45, 'Seidel', 'lidia', NULL, NULL),
(46, 'Strozycka', 'lorena', NULL, NULL),
(47, 'Hamerak', 'Magdalena', NULL, NULL),
(48, 'Kozikiewicz', 'Magdalena', NULL, NULL),
(49, 'Jelonek', 'Marcin', NULL, NULL),
(50, 'Finkel', 'Marek', NULL, NULL),
(51, 'Haberko', 'Marek', NULL, NULL),
(52, 'Wawrzynowski', 'Marek', NULL, NULL),
(53, 'Golawska', 'Maria', NULL, NULL),
(54, 'Wrobl', 'Maria', NULL, NULL),
(55, 'Konieczny', 'Marian', NULL, NULL),
(56, 'lencki', 'Marian', NULL, NULL),
(57, 'Finkel', 'Mariola', NULL, NULL),
(58, 'Beskowicz', 'Mariusz', NULL, NULL),
(59, 'Koralewski', 'Mariusz', NULL, NULL),
(60, 'Prozalska', 'Malgorzata', NULL, NULL),
(61, 'Goralczyk', 'Michal', NULL, NULL),
(62, 'Misiewicz', 'Michal', NULL, NULL),
(63, 'Tomiczek', 'Michal', NULL, NULL),
(64, 'Jedrzejczak', 'Mieczyslaw', NULL, NULL),
(65, 'Jarzembowski', 'Miroslaw', NULL, NULL),
(66, 'Szajda', 'Miroslawa', NULL, NULL),
(67, 'Wojtasiak', 'Monika', NULL, NULL),
(68, 'Zapotoczny', 'Norbert', NULL, NULL),
(69, 'Piekarzewski', 'Pawel', NULL, NULL),
(70, 'Nawrocki', 'Piotr', NULL, NULL),
(71, 'Ritter', 'Piotr', NULL, NULL),
(72, 'Czarnecki', 'Przemyslaw', NULL, NULL),
(73, 'Zetlerowicz', 'Radoslaw', NULL, NULL),
(74, 'Dubielski', 'Robert', NULL, NULL),
(75, 'Piekarzewski', 'Robert', NULL, NULL),
(76, 'Kazmierczak', 'Roman', NULL, NULL),
(77, 'Mlodozeniec', 'Roman', NULL, NULL),
(78, 'Gasiorowski', 'Ryszard', NULL, NULL),
(79, 'Kowalski', 'Sebastian', NULL, NULL),
(80, 'Szelagowski', 'Sebastian', NULL, NULL),
(81, 'Mikulajewski', 'Stanislaw', NULL, NULL),
(82, 'Prozalski', 'Stanislaw', NULL, NULL),
(83, 'Slawinski', 'Szymon', NULL, NULL),
(84, 'Iwaszkiewicz', 'Slawomir', NULL, NULL),
(85, 'Fickowski', 'Tadeusz', NULL, NULL),
(86, 'Kwiatkowski', 'Tadeusz', NULL, NULL),
(87, 'Spychala', 'Tadeusz', NULL, NULL),
(88, 'Kozikiewicz', 'Tomasz', NULL, NULL),
(89, 'Olejniczak', 'Tomasz', NULL, NULL),
(90, 'Stefankiewicz', 'Tomasz', NULL, NULL),
(91, 'Strozycki', 'Tomasz', NULL, NULL),
(92, 'Tonak', 'Tomasz', NULL, NULL),
(93, 'Krugiolka', 'Tomasz', NULL, NULL),
(94, 'Strozycki', 'Wojciech', NULL, NULL),
(95, 'Piasecki', 'Zbigniew', NULL, NULL),
(96, 'Lehmann', 'Zdzislaw', NULL, NULL),
(97, 'Kasprzak', 'Zofia', NULL, NULL),
(98, 'Hajzer', 'Gerwazy', NULL, NULL),
(99, 'Kot', 'Jerzy', NULL, NULL),
(100, 'Kot', 'Jerzy', NULL, NULL),
(101, 'Lis', 'Jerzy', NULL, NULL),
(102, 'Lis', 'Jerzy', NULL, NULL),
(103, 'Lis', 'Jerzy', NULL, NULL),
(104, 'Lis', 'Jerzy', NULL, NULL),
(105, 'Lis', 'Jerzy', NULL, NULL),
(106, 'Lis', 'Jerzy', NULL, NULL),
(107, 'Lis', 'Jerzy', NULL, NULL),
(108, 'Lis', 'Jerzy', NULL, NULL),
(109, 'Lis', 'Jerzy', NULL, NULL),
(110, 'Lis', 'Jerzy', NULL, NULL),
(111, 'Lis', 'Jerzy', NULL, NULL),
(112, 'Lis', 'Jerzy', NULL, NULL),
(113, 'Lis', 'Jerzy', NULL, NULL),
(114, 'Lis', 'Jerzy', NULL, NULL),
(115, 'Lis', 'Jerzy', NULL, NULL),
(116, 'Lis', 'Jerzy', NULL, NULL),
(117, 'Lis', 'Jerzy', NULL, NULL),
(118, 'Lis', 'Jerzy', NULL, NULL),
(119, 'Lis', 'Jerzy', NULL, NULL),
(120, 'Lis', 'Julia', NULL, NULL),
(121, 'Pies', '*11B927C024A68AEE6FDE498751F25A193E845C29', NULL, NULL),
(122, 'Lis', 'Julia', NULL, NULL),
(123, 'Lis', 'Julia', NULL, NULL),
(124, 'Lis', 'Julia', NULL, NULL),
(125, 'Lis', 'Julia', NULL, NULL),
(126, 'Lis', 'Julia', NULL, NULL),
(127, 'Lis', 'Julia', NULL, NULL),
(128, 'Lis', 'Julia', NULL, NULL),
(129, 'Lis', 'Julia', NULL, NULL),
(130, 'Lis', 'Julia', NULL, NULL),
(131, 'Lis', 'Julia', NULL, NULL),
(132, 'Lis', 'Julia', NULL, NULL),
(133, 'Lis', 'Julia', NULL, NULL),
(136, 'j', 'j', NULL, NULL),
(137, 'k', 'k', NULL, NULL),
(138, 'Adamski', 'Adam', NULL, NULL);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `mieszkania`
--
ALTER TABLE `mieszkania`
  ADD PRIMARY KEY (`Nrdomku`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD KEY `IdPracownika` (`IdPracownika`),
  ADD KEY `NrDomku` (`NrDomku`);

--
-- Indeksy dla tabeli `uczen`
--
ALTER TABLE `uczen`
  ADD PRIMARY KEY (`Idpracownika`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `mieszkania`
--
ALTER TABLE `mieszkania`
  MODIFY `Nrdomku` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `uczen`
--
ALTER TABLE `uczen`
  MODIFY `Idpracownika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
