CREATE DATABASE `MR_czerwiec_2023`;

CREATE TABLE `kraje`
(
    `kod_k` char(2) PRIMARY KEY,
    `nazwa_k` varchar(50),
    `ludnosc_k` int(10) unsigned
);

CREATE TABLE `urzadzenia`
(
    `kod_u` int(5) PRIMARY key,
    `nazwa_u` varchar(80),
    `producent_u` varchar(35),
    `typ_u` enum('Tablet','Phone','PC')
);

CREATE TABLE `instalacje`
(
    `data_i` date,
    `kod_u` int(5),
    `kod_k` char(2)
);