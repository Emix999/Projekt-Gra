-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 31 Paź 2023, 13:45
-- Wersja serwera: 10.4.27-MariaDB
-- Wersja PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `domki3110`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `mieszkania`
--

CREATE TABLE `mieszkania` (
  `Nrdomku` tinyint(4) NOT NULL,
  `LiczbaPokoi` tinyint(3) UNSIGNED NOT NULL,
  `Garaz` enum('Tak','Nie') DEFAULT NULL,
  `CenaZaDobe` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `mieszkania`
--

INSERT INTO `mieszkania` (`Nrdomku`, `LiczbaPokoi`, `Garaz`, `CenaZaDobe`) VALUES
(1, 4, 'Tak', 200),
(2, 4, 'Nie', 160),
(3, 2, 'Tak', 120),
(4, 2, 'Nie', 100),
(5, 3, 'Tak', 170),
(6, 3, 'Nie', 140),
(7, 5, 'Tak', 250),
(8, 5, 'Nie', 200),
(9, 6, 'Tak', 300);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `NrRezerwacji` int(11) NOT NULL,
  `IdPracownika` int(11) DEFAULT NULL,
  `NrDomku` tinyint(4) DEFAULT NULL,
  `LiczbaDni` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `rezerwacje`
--

INSERT INTO `rezerwacje` (`NrRezerwacji`, `IdPracownika`, `NrDomku`, `LiczbaDni`) VALUES
(1, 5, 2, 2),
(2, 20, 5, 2),
(3, 35, 6, 3),
(4, 26, 2, 2),
(5, 58, 3, 4),
(6, 72, 6, 2),
(7, 74, 8, 4),
(8, 85, 7, 10),
(9, 57, 6, 4),
(10, 50, 9, 2),
(11, 36, 5, 4),
(12, 24, 4, 1),
(13, 78, 3, 7),
(14, 53, 4, 2),
(15, 6, 6, 2),
(16, 61, 5, 7),
(17, 31, 3, 6),
(18, 51, 2, 3),
(19, 37, 8, 5),
(20, 47, 1, 5),
(21, 19, 2, 2),
(22, 29, 4, 4),
(23, 84, 2, 10),
(24, 65, 5, 2),
(25, 49, 6, 1),
(26, 64, 3, 7),
(27, 97, 2, 8),
(28, 76, 7, 2),
(29, 55, 5, 3),
(30, 59, 3, 4),
(31, 79, 2, 7),
(32, 88, 7, 4),
(33, 48, 5, 1),
(34, 93, 9, 4),
(35, 17, 9, 5),
(36, 15, 9, 3),
(37, 86, 8, 10),
(38, 25, 5, 2),
(39, 44, 3, 2),
(40, 96, 2, 3),
(41, 56, 4, 2),
(42, 11, 6, 3),
(43, 40, 8, 2),
(44, 7, 4, 2),
(45, 32, 2, 3),
(46, 9, 1, 2),
(47, 38, 5, 4),
(48, 81, 7, 7),
(49, 62, 8, 7),
(50, 77, 4, 2),
(51, 70, 6, 4),
(52, 89, 9, 2),
(53, 12, 8, 4),
(54, 8, 7, 2),
(55, 95, 2, 2),
(56, 69, 2, 4),
(57, 75, 3, 2),
(58, 18, 7, 6),
(59, 60, 6, 2),
(60, 82, 4, 8),
(61, 34, 7, 3),
(62, 27, 5, 2),
(63, 30, 4, 5),
(64, 28, 7, 3),
(65, 16, 8, 4),
(66, 71, 6, 3),
(67, 10, 4, 2),
(68, 13, 2, 5),
(69, 45, 1, 3),
(70, 42, 1, 2),
(71, 83, 1, 8),
(72, 87, 1, 2),
(73, 41, 5, 3),
(74, 90, 7, 5),
(75, 46, 5, 4),
(76, 91, 3, 7),
(77, 94, 8, 3),
(78, 66, 6, 3),
(79, 80, 8, 7),
(80, 63, 9, 7),
(81, 92, 6, 5),
(82, 4, 6, 3),
(83, 22, 8, 2),
(84, 43, 3, 2),
(85, 52, 2, 2),
(86, 39, 3, 2),
(87, 67, 1, 4),
(88, 33, 1, 3),
(89, 54, 9, 2),
(90, 23, 7, 2),
(91, 1, 5, 5),
(92, 14, 4, 4),
(93, 2, 3, 5),
(94, 68, 4, 5),
(95, 3, 2, 5),
(96, 73, 3, 3),
(97, 21, 4, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uczen`
--

CREATE TABLE `uczen` (
  `Idpracownika` int(11) NOT NULL,
  `Nazwisko` varchar(50) DEFAULT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `wiek` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Zrzut danych tabeli `uczen`
--

INSERT INTO `uczen` (`Idpracownika`, `Nazwisko`, `imie`, `wiek`) VALUES
(1, 'Wroblewski', 'Jan', NULL),
(2, 'Wiecek', 'Jaremi', NULL),
(3, 'Zawada', 'Witold', NULL),
(4, 'Ulatowski', 'Edwin', NULL),
(5, 'Adamski', 'Adam', NULL),
(6, 'Gosciniak', 'Agnieszka', NULL),
(7, 'September', 'Agnieszka', NULL),
(8, 'Owocka', 'Agnieszka', NULL),
(9, 'Mikolajczyk', 'Aldona', NULL),
(10, 'Rokicka', 'Aleksandra', NULL),
(11, 'lis', 'Andrzej', NULL),
(12, 'Opielski', 'Andrzej', NULL),
(13, 'Sadej', 'Andrzej', NULL),
(14, 'Zajdowicz', 'Arleta', NULL),
(15, 'Kuryllo', 'Artur', NULL),
(16, 'Ratajczyk', 'Artur', NULL),
(17, 'Kujawa', 'Bogdan', NULL),
(18, 'Prokopowicz', 'Bogdan', NULL),
(19, 'Hamerak', 'Blazej', NULL),
(20, 'Antasowski', 'Dariusz', NULL),
(21, 'Zielinska', 'Dariusz', NULL),
(22, 'Walkusz', 'Elzbieta', NULL),
(23, 'Wrobl', 'Elzbieta', NULL),
(24, 'Garbatowska', 'Ewa', NULL),
(25, 'lazowski', 'Ewa', NULL),
(26, 'Bardzewska', 'Grazyna', NULL),
(27, 'Radziemski', 'Grzegorz', NULL),
(28, 'Rak', 'Grzegorz', NULL),
(29, 'Iwanowska', 'Hanka', NULL),
(30, 'Rajkowski', 'Hieronim', NULL),
(31, 'Gorna', 'Ilona', NULL),
(32, 'Magdzinska', 'Irena', NULL),
(33, 'Wojtasiak', 'Jacek', NULL),
(34, 'Radke', 'Jan', NULL),
(35, 'Baran', 'Janusz', NULL),
(36, 'Fratczak', 'Janusz', NULL),
(37, 'Hadynski', 'Jaroslaw', NULL),
(38, 'Mikulajewski', 'Jerzy', NULL),
(39, 'Wilkowska', 'Kamila', NULL),
(40, 'lisiecki', 'Karol', NULL),
(41, 'Stachowiak', 'Katarzyna', NULL),
(42, 'Sikorska', 'Kinga', NULL),
(43, 'Wawrzyniak', 'Krzysztofa', NULL),
(44, 'laczkowski', 'leszek', NULL),
(45, 'Seidel', 'lidia', NULL),
(46, 'Strozycka', 'lorena', NULL),
(47, 'Hamerak', 'Magdalena', NULL),
(48, 'Kozikiewicz', 'Magdalena', NULL),
(49, 'Jelonek', 'Marcin', NULL),
(50, 'Finkel', 'Marek', NULL),
(51, 'Haberko', 'Marek', NULL),
(52, 'Wawrzynowski', 'Marek', NULL),
(53, 'Golawska', 'Maria', NULL),
(54, 'Wrobl', 'Maria', NULL),
(55, 'Konieczny', 'Marian', NULL),
(56, 'lencki', 'Marian', NULL),
(57, 'Finkel', 'Mariola', NULL),
(58, 'Beskowicz', 'Mariusz', NULL),
(59, 'Koralewski', 'Mariusz', NULL),
(60, 'Prozalska', 'Malgorzata', NULL),
(61, 'Goralczyk', 'Michal', NULL),
(62, 'Misiewicz', 'Michal', NULL),
(63, 'Tomiczek', 'Michal', NULL),
(64, 'Jedrzejczak', 'Mieczyslaw', NULL),
(65, 'Jarzembowski', 'Miroslaw', NULL),
(66, 'Szajda', 'Miroslawa', NULL),
(67, 'Wojtasiak', 'Monika', NULL),
(68, 'Zapotoczny', 'Norbert', NULL),
(69, 'Piekarzewski', 'Pawel', NULL),
(70, 'Nawrocki', 'Piotr', NULL),
(71, 'Ritter', 'Piotr', NULL),
(72, 'Czarnecki', 'Przemyslaw', NULL),
(73, 'Zetlerowicz', 'Radoslaw', NULL),
(74, 'Dubielski', 'Robert', NULL),
(75, 'Piekarzewski', 'Robert', NULL),
(76, 'Kazmierczak', 'Roman', NULL),
(77, 'Mlodozeniec', 'Roman', NULL),
(78, 'Gasiorowski', 'Ryszard', NULL),
(79, 'Kowalski', 'Sebastian', NULL),
(80, 'Szelagowski', 'Sebastian', NULL),
(81, 'Mikulajewski', 'Stanislaw', NULL),
(82, 'Prozalski', 'Stanislaw', NULL),
(83, 'Slawinski', 'Szymon', NULL),
(84, 'Iwaszkiewicz', 'Slawomir', NULL),
(85, 'Fickowski', 'Tadeusz', NULL),
(86, 'Kwiatkowski', 'Tadeusz', NULL),
(87, 'Spychala', 'Tadeusz', NULL),
(88, 'Kozikiewicz', 'Tomasz', NULL),
(89, 'Olejniczak', 'Tomasz', NULL),
(90, 'Stefankiewicz', 'Tomasz', NULL),
(91, 'Strozycki', 'Tomasz', NULL),
(92, 'Tonak', 'Tomasz', NULL),
(93, 'Krugiolka', 'Tomasz', NULL),
(94, 'Strozycki', 'Wojciech', NULL),
(95, 'Piasecki', 'Zbigniew', NULL),
(96, 'Lehmann', 'Zdzislaw', NULL),
(97, 'Kasprzak', 'Zofia', NULL),
(98, 'Hajzer', 'Gerwazy', NULL),
(99, 'Kot', 'Jerzy', NULL),
(100, 'Kot', 'Jerzy', NULL),
(101, 'Lis', 'Jerzy', NULL),
(102, 'Lis', 'Jerzy', NULL),
(103, 'Lis', 'Jerzy', NULL),
(104, 'Lis', 'Jerzy', NULL),
(105, 'Lis', 'Jerzy', NULL),
(106, 'Lis', 'Jerzy', NULL),
(107, 'Lis', 'Jerzy', NULL),
(108, 'Lis', 'Jerzy', NULL),
(109, 'Lis', 'Jerzy', NULL),
(110, 'Lis', 'Jerzy', NULL),
(111, 'Lis', 'Jerzy', NULL),
(112, 'Lis', 'Jerzy', NULL),
(113, 'Lis', 'Jerzy', NULL),
(114, 'Lis', 'Jerzy', NULL),
(115, 'Lis', 'Jerzy', NULL),
(116, 'Lis', 'Jerzy', NULL),
(117, 'Lis', 'Jerzy', NULL),
(118, 'Lis', 'Jerzy', NULL),
(119, 'Lis', 'Jerzy', NULL),
(120, 'Lis', 'Julia', NULL),
(121, 'Pies', '*11B927C024A68AEE6FDE498751F25A193E845C29', NULL),
(122, 'Lis', 'Julia', NULL),
(123, 'Lis', 'Julia', NULL),
(124, 'Lis', 'Julia', NULL),
(125, 'Lis', 'Julia', NULL),
(126, 'Lis', 'Julia', NULL),
(127, 'Lis', 'Julia', NULL),
(128, 'Lis', 'Julia', NULL),
(129, 'Lis', 'Julia', NULL),
(130, 'Lis', 'Julia', NULL),
(131, 'Lis', 'Julia', NULL),
(132, 'Lis', 'Julia', NULL),
(133, 'Lis', 'Julia', NULL),
(136, 'j', 'j', NULL),
(137, 'k', 'k', NULL),
(138, 'Adamski', 'Adam', NULL);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `mieszkania`
--
ALTER TABLE `mieszkania`
  ADD PRIMARY KEY (`Nrdomku`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD PRIMARY KEY (`NrRezerwacji`),
  ADD KEY `IdPracownika` (`IdPracownika`),
  ADD KEY `NrDomku` (`NrDomku`);

--
-- Indeksy dla tabeli `uczen`
--
ALTER TABLE `uczen`
  ADD PRIMARY KEY (`Idpracownika`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `mieszkania`
--
ALTER TABLE `mieszkania`
  MODIFY `Nrdomku` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  MODIFY `NrRezerwacji` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT dla tabeli `uczen`
--
ALTER TABLE `uczen`
  MODIFY `Idpracownika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD CONSTRAINT `rezerwacje_ibfk_1` FOREIGN KEY (`IdPracownika`) REFERENCES `uczen` (`Idpracownika`),
  ADD CONSTRAINT `rezerwacje_ibfk_2` FOREIGN KEY (`NrDomku`) REFERENCES `mieszkania` (`Nrdomku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
